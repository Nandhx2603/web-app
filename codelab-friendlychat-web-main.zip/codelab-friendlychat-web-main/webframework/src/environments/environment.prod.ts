export const environment = {
    production: true,
    firebase: {
        // Your Firebase APIs here
    },
  };
