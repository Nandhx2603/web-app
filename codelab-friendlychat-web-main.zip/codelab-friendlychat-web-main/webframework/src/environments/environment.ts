export const environment = {
  production: false,
  firebase: {
    // Your Firebase APIs here
  },
};
